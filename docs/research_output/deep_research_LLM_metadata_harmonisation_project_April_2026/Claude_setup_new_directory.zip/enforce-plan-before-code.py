#!/usr/bin/env python3
"""
PreToolUse hook: Blocks code edits to src/ unless a plan exists.
Place in .claude/hooks/ and register as a PreToolUse hook for Write and Edit tools.

Hook event: PreToolUse
Tools: Write, Edit, MultiEdit
"""

import json
import sys
import os
import glob


def main():
    # Read hook input from stdin
    hook_input = json.loads(sys.stdin.read())
    
    tool_name = hook_input.get("tool_name", "")
    tool_input = hook_input.get("tool_input", {})
    
    # Only check Write/Edit tools
    if tool_name not in ("Write", "Edit", "MultiEdit"):
        # Allow other tools
        print(json.dumps({"decision": "approve"}))
        return
    
    # Get the file path being edited
    file_path = tool_input.get("file_path", "") or tool_input.get("path", "")
    
    # Only enforce for src/ directory (adjust to your project structure)
    enforced_dirs = ["src/", "lib/", "app/"]
    is_enforced = any(file_path.startswith(d) or f"/{d}" in file_path for d in enforced_dirs)
    
    if not is_enforced:
        print(json.dumps({"decision": "approve"}))
        return
    
    # Check if a plan exists in plans/specs/
    plan_dir = "plans/specs"
    if os.path.isdir(plan_dir):
        plans = glob.glob(os.path.join(plan_dir, "*.md"))
        if plans:
            # At least one plan exists — allow the edit
            print(json.dumps({"decision": "approve"}))
            return
    
    # No plan found — block with message
    print(json.dumps({
        "decision": "block",
        "reason": (
            "🚫 No plan found in plans/specs/. "
            "You must create a plan before writing implementation code. "
            "Run /ce:brainstorm to start, then /ce:plan to create the spec."
        )
    }))


if __name__ == "__main__":
    main()
