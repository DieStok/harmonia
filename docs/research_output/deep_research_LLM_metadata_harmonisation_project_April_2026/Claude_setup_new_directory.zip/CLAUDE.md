# CLAUDE.md — Enforced Development Loop

## Core Philosophy

Each unit of engineering work must make subsequent units easier. 80% planning and review, 20% execution. No code is written without a plan. No feature ships without adversarial review.

## Mandatory Development Loop

Every feature, bugfix, or refactor MUST follow this sequence. Skipping phases is forbidden.

### Phase 1: Brainstorm (`/ce:brainstorm`)
- Start every new feature here. No exceptions.
- Use AskUserQuestion tool to interview the developer interactively.
- Produce a requirements document in `plans/requirements/`.
- Generate mermaid diagrams showing user flows, data flows, and edge cases.
- Output goes to `plans/brainstorm/<feature-name>.md`.

### Phase 2: Plan + Architect (`/ce:plan`)
- Takes requirements from Phase 1 as input.
- Produce a technical spec with:
  - Mermaid architecture diagrams (component relationships, data flow, sequence diagrams)
  - Complete function/method signatures with types, params, and return values
  - File-by-file change list with rationale
  - Test plan: unit tests, integration tests, edge cases
  - Explicit acceptance criteria (checkboxes)
- Output goes to `plans/specs/<feature-name>.md`.
- Use Opus model for planning (`/model opus`), Sonnet for implementation.

<important if="developer tries to skip planning or jump to code">
STOP. Do not write any implementation code until a plan exists in plans/specs/ and the developer has explicitly approved it. Ask: "I need to see an approved plan before writing code. Should we start with /ce:brainstorm or /ce:plan?"
</important>

### Phase 3: Implement with TDD (`/ce:work`)
- ALWAYS write tests FIRST, then implementation code.
- For each task in the plan:
  1. Write failing test(s) that encode the acceptance criteria
  2. Run tests to confirm they fail (red)
  3. Write minimal code to pass (green)
  4. Refactor while tests stay green
- Use git worktrees for parallel tasks when possible.
- Commit after each passing test cycle. Minimum: 1 commit per hour.
- Reference the plan file in commit messages: `feat: <description> [plan: <feature-name>]`

<important if="developer asks to write code without tests">
STOP. TDD is mandatory. Write the test first, confirm it fails, then implement. Say: "Let me write the test first to define what success looks like."
</important>

### Phase 4: Adversarial Review (`/ce:review`)
- After implementation, a SEPARATE agent context reviews the work.
- The review agent is instructed to be adversarial — its job is to find problems.
- Review checks (all must pass):
  - [ ] Implementation matches the spec in `plans/specs/<feature-name>.md`
  - [ ] All acceptance criteria from the plan are met
  - [ ] No code smells (dead code, god objects, shotgun surgery, feature envy)
  - [ ] No unhandled edge cases identified in brainstorm
  - [ ] Test coverage is sufficient (not just happy path)
  - [ ] No regressions to existing functionality
  - [ ] Security review passes (auth, input validation, data exposure)
  - [ ] Performance characteristics are acceptable
- If review fails: loop back to Phase 3 with specific rework items.
- If review passes: proceed to compound.

### Phase 5: Compound (`/ce:compound`)
- Document what was learned in `.claude/learnings/`.
- Update CLAUDE.md rules if new patterns emerged.
- Archive the plan and spec for future reference.

## Mermaid Diagram Requirements

When producing architecture or design diagrams, ALWAYS use mermaid syntax rendered to files. Include:

```
- flowchart TD for process flows
- sequenceDiagram for API/service interactions
- classDiagram for data models and relationships
- erDiagram for database schemas
- stateDiagram-v2 for state machines
```

Every plan MUST contain at least:
1. A high-level architecture diagram (flowchart or component)
2. A sequence diagram for the primary user flow
3. A data model diagram if new models are introduced

## Function Signature Requirements

Before implementation, the plan must include typed function signatures for all new public functions/methods:

```
// Example format:
function processOrder(
  order: Order,
  options?: ProcessOptions
): Promise<ProcessResult>

interface ProcessOptions {
  validateInventory: boolean;
  notifyCustomer: boolean;
  retryCount?: number; // default: 3
}

interface ProcessResult {
  success: boolean;
  orderId: string;
  errors?: ValidationError[];
}
```

## Directory Structure

```
plans/
  brainstorm/       # Phase 1 outputs (requirements, initial diagrams)
  specs/            # Phase 2 outputs (tech specs, architecture, signatures)
  reviews/          # Phase 4 outputs (review reports, rework items)
.claude/
  learnings/        # Phase 5 outputs (documented patterns, gotchas)
  agents/           # Subagent definitions
  commands/         # Slash command definitions
  hooks/            # Hook scripts
```

## Hooks Enforcement

The following hooks enforce this workflow:

- **PreToolUse (Write/Edit)**: Checks that a plan file exists for the current feature before allowing code changes. Blocks edits to src/ without an approved plan.
- **PostToolUse (Write/Edit)**: Auto-formats code after every edit.
- **Stop hook**: At end of turn, checks if tests exist for new code. Nudges to write tests if missing.
- **PreToolUse (Bash: git commit)**: Validates commit message references a plan file.

## Context Management

- Run `/compact` at 50% context usage. Never let it exceed 70%.
- Use `/clear` when switching features.
- Use subagents for isolated tasks to keep main context clean.
- Use `ultrathink` keyword for complex architectural decisions.

## Model Usage

- **Opus**: Planning, architecture, complex debugging, adversarial review
- **Sonnet**: Implementation, tests, refactoring, simple fixes
- Switch with `/model` as appropriate for the phase.
