#!/usr/bin/env python3
"""
Stop hook: Checks if new code has corresponding tests.
Nudges Claude to write tests if implementation files were created without test files.

Hook event: Stop
"""

import json
import sys
import os
import subprocess


def get_recently_modified_files():
    """Get files modified in the last git commit or unstaged."""
    try:
        # Check staged + unstaged changes
        result = subprocess.run(
            ["git", "diff", "--name-only", "HEAD"],
            capture_output=True, text=True, timeout=5
        )
        files = result.stdout.strip().split("\n") if result.stdout.strip() else []
        
        # Also check untracked files
        result2 = subprocess.run(
            ["git", "ls-files", "--others", "--exclude-standard"],
            capture_output=True, text=True, timeout=5
        )
        files += result2.stdout.strip().split("\n") if result2.stdout.strip() else []
        
        return [f for f in files if f]
    except Exception:
        return []


def is_implementation_file(path):
    """Check if file is implementation code (not test, not config)."""
    impl_dirs = ["src/", "lib/", "app/"]
    impl_extensions = [".ts", ".tsx", ".js", ".jsx", ".py", ".rb", ".go", ".rs"]
    
    if not any(path.startswith(d) for d in impl_dirs):
        return False
    if not any(path.endswith(ext) for ext in impl_extensions):
        return False
    # Exclude test files
    test_patterns = ["test", "spec", "__test__", ".test.", ".spec.", "_test."]
    if any(p in path.lower() for p in test_patterns):
        return False
    return True


def find_test_file(impl_path):
    """Check if a corresponding test file exists."""
    base = os.path.splitext(impl_path)[0]
    ext = os.path.splitext(impl_path)[1]
    name = os.path.basename(base)
    directory = os.path.dirname(impl_path)
    
    # Common test file patterns
    candidates = [
        f"{base}.test{ext}",
        f"{base}.spec{ext}",
        f"{base}_test{ext}",
        os.path.join(directory, "__tests__", f"{name}{ext}"),
        os.path.join(directory, "__tests__", f"{name}.test{ext}"),
        impl_path.replace("src/", "tests/", 1),
        impl_path.replace("src/", "test/", 1),
        impl_path.replace("lib/", "tests/", 1),
        impl_path.replace("app/", "tests/", 1),
    ]
    
    return any(os.path.exists(c) for c in candidates)


def main():
    modified = get_recently_modified_files()
    impl_files_without_tests = []
    
    for f in modified:
        if is_implementation_file(f) and not find_test_file(f):
            impl_files_without_tests.append(f)
    
    if impl_files_without_tests:
        file_list = "\n".join(f"  - {f}" for f in impl_files_without_tests[:5])
        print(json.dumps({
            "decision": "block",
            "reason": (
                f"⚠️ TDD check: These implementation files have no corresponding tests:\n"
                f"{file_list}\n\n"
                "Write tests before continuing. TDD is mandatory: "
                "write a failing test first, then make it pass."
            )
        }))
    else:
        print(json.dumps({"decision": "approve"}))


if __name__ == "__main__":
    main()
