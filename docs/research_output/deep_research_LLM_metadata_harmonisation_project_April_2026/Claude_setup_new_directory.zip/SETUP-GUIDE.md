# Complete Setup Guide: Enforced Development Loop with Claude Code

## Overview

This guide sets up a rigorous **Brainstorm → Plan → Implement → Adversarial Review → Compound** loop using Claude Code, the Compound Engineering plugin, custom hooks, and adversarial review agents.

---

## 1. What You Already Have: Compound Engineering Plugin

Your installed `compound-engineering-plugin` provides the core workflow commands:

| Command | Phase | What It Does |
|---------|-------|--------------|
| `/ce:brainstorm` | 1 - Brainstorm | Interactive Q&A to refine requirements into a structured document |
| `/ce:plan` | 2 - Plan | Converts requirements into a technical spec with architecture |
| `/ce:work` | 3 - Implement | Executes tasks from the plan with worktree support |
| `/ce:review` | 4 - Review | Multi-agent code review with 35+ specialized reviewer agents |
| `/ce:compound` | 5 - Compound | Documents learnings for future reuse |
| `/ce:ideate` | Pre-loop | Discovers high-impact improvements through divergent ideation |

The plugin already includes these adversarial review agents that align with your goals:
- `adversarial-reviewer` — constructs failure scenarios across component boundaries
- `adversarial-document-reviewer` — challenges premises and stress-tests decisions
- `correctness-reviewer` — logic errors, edge cases, state bugs
- `code-simplicity-reviewer` — final pass for minimalism
- `security-reviewer` — exploitable vulnerabilities with confidence calibration
- `testing-reviewer` — test coverage gaps and weak assertions
- `architecture-strategist` — architectural decisions and compliance
- `scope-guardian-reviewer` — challenges unjustified complexity and scope creep

## 2. What To Add: Enforcement Layer

The Compound Engineering plugin provides the *tools* but doesn't *enforce* their use. The files in this package add enforcement.

### File Placement

Copy these files into your project:

```
your-project/
├── CLAUDE.md                              ← Root (enforces the loop)
├── plans/
│   ├── brainstorm/                        ← Phase 1 outputs
│   ├── specs/                             ← Phase 2 outputs  
│   └── reviews/                           ← Phase 4 outputs
├── .claude/
│   ├── settings.json                      ← Hook registrations + permissions
│   ├── hooks/
│   │   ├── enforce-plan-before-code.py    ← Blocks code without a plan
│   │   └── check-tests-on-stop.py         ← Nudges to write tests
│   ├── agents/
│   │   └── adversarial-reviewer.md        ← Custom adversarial agent
│   └── learnings/                         ← Phase 5 outputs
```

### Make hooks executable

```bash
chmod +x .claude/hooks/enforce-plan-before-code.py
chmod +x .claude/hooks/check-tests-on-stop.py
```

### Create plan directories

```bash
mkdir -p plans/brainstorm plans/specs plans/reviews .claude/learnings
```

## 3. The Enforced Workflow In Practice

### Starting a new feature

```
claude
> /ce:brainstorm
```

Claude interviews you about the feature, produces a requirements doc in `plans/brainstorm/`, and generates mermaid diagrams.

### Planning with diagrams and signatures

```
> /ce:plan
```

Tell Claude: "Include mermaid architecture diagrams, sequence diagrams for the main flows, and typed function signatures for all new public APIs."

The plan lands in `plans/specs/<feature>.md`. Review it. The hook will block any code edits to `src/` until this file exists.

### Getting mermaid diagrams in-depth

In your prompt during planning, say:

```
Generate the following mermaid diagrams:
1. flowchart TD showing the high-level component architecture
2. sequenceDiagram for the primary user flow  
3. classDiagram for new data models
4. erDiagram if new database tables are involved
5. stateDiagram-v2 for any state machines

Render each to a .mermaid file in plans/specs/diagrams/
```

Claude will produce these and you can review them before implementation.

### Implementing with TDD

```
> /ce:work
```

The CLAUDE.md enforces test-first development. The Stop hook checks that every new implementation file has a corresponding test file. If you try to commit code without tests, it blocks.

### Adversarial review (separate agent)

```
> /ce:review
```

This spawns review subagents in isolated contexts. The compound engineering plugin's built-in reviewers run, plus your custom `adversarial-reviewer` agent which specifically checks spec conformance and code smells.

For maximum rigor, you can also spin up a second Claude instance:

```bash
# In a separate terminal
claude --agent-file .claude/agents/adversarial-reviewer.md
> Review the implementation of <feature> against plans/specs/<feature>.md
```

This gives you a completely fresh context that hasn't seen the implementation process.

### Compounding

```
> /ce:compound
```

Documents what was learned, updates patterns, archives the plan.

## 4. Hooks Reference

### enforce-plan-before-code.py (PreToolUse)

**Trigger**: Any Write/Edit/MultiEdit to files in `src/`, `lib/`, or `app/`
**Behavior**: Checks if any `.md` file exists in `plans/specs/`. If not, blocks the edit.
**Customize**: Edit the `enforced_dirs` list to match your project structure.

### check-tests-on-stop.py (Stop)

**Trigger**: End of every Claude turn
**Behavior**: Checks git diff for new implementation files without corresponding test files.
**Customize**: Edit `is_implementation_file()` and `find_test_file()` for your conventions.

### Additional hooks to consider

| Hook Event | Purpose | Script |
|------------|---------|--------|
| `PostToolUse(Bash)` | Auto-format after code generation | Run prettier/black/rustfmt |
| `PreToolUse(Bash: git commit)` | Validate commit message format | Check for plan reference |
| `Stop` | At end of turn, verify tests pass | Run `npm test` / `pytest` |
| `PermissionRequest` | Route risky operations through Opus | Security scanning |

## 5. Tips for Maximum Effectiveness

### During brainstorm
- Say "grill me on these requirements" to get Claude to challenge your assumptions
- Use `/ce:ideate` first if you're unsure what to build

### During planning  
- Say "ultrathink" for complex architectural decisions
- Ask Claude to "prove this architecture handles <edge case>"
- Request ASCII diagrams in addition to mermaid for quick in-terminal review

### During implementation
- Use `/model sonnet` for implementation speed
- Say "use subagents" to parallelize independent tasks
- Commit after every passing test cycle

### During review
- Spin up a second Claude in a separate terminal for truly independent review
- Say "knowing everything you know now, scrap this and implement the elegant solution" if the review reveals fundamental issues
- Use cross-model review: have Codex or another model review Claude's output

### Context management
- `/compact` at 50% context usage
- `/clear` when switching between features
- `/rename` sessions so you can `/resume` them later
- Never let context exceed 70% — quality degrades

## 6. Integration with Compound Engineering Commands

The plugin commands and your custom enforcement work together:

```
/ce:brainstorm  →  creates plans/brainstorm/<feature>.md
                    (hook allows planning files to be written)
                    
/ce:plan        →  creates plans/specs/<feature>.md
                    (hook now allows src/ edits since plan exists)
                    
/ce:work        →  edits src/ files with TDD
                    (Stop hook checks for test files)
                    
/ce:review      →  spawns adversarial review agents
                    (your custom agent + 35 built-in reviewers)
                    (creates plans/reviews/<feature>-review.md)
                    
/ce:compound    →  documents learnings
                    (updates .claude/learnings/)
```

The hooks enforce the ordering. The agents enforce the quality. The CLAUDE.md ties it all together.
